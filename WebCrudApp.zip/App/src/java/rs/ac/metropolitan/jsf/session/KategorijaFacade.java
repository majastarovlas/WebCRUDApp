/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jsf.session;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import rs.ac.metropolitan.jpa.entity.Kategorija;

/**
 *
 * @author MSI
 */
@Stateless
public class KategorijaFacade extends AbstractFacade<Kategorija> {

    @PersistenceContext(unitName = "CS230-ProjekatPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public KategorijaFacade() {
        super(Kategorija.class);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author MSI
 */
@Entity
@Table(name = "napisanaknjiga")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Napisanaknjiga.findAll", query = "SELECT n FROM Napisanaknjiga n")
    , @NamedQuery(name = "Napisanaknjiga.findByIdNk", query = "SELECT n FROM Napisanaknjiga n WHERE n.idNk = :idNk")})
public class Napisanaknjiga implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_NK")
    private Integer idNk;
    @JoinColumn(name = "ID_KNJIGA", referencedColumnName = "ID_KNJIGA")
    @ManyToOne(optional = false)
    private Knjiga idKnjiga;
    @JoinColumn(name = "ID_AUTOR", referencedColumnName = "ID_AUTOR")
    @ManyToOne(optional = false)
    private Autor idAutor;

    public Napisanaknjiga() {
    }

    public Napisanaknjiga(Integer idNk) {
        this.idNk = idNk;
    }

    public Integer getIdNk() {
        return idNk;
    }

    public void setIdNk(Integer idNk) {
        this.idNk = idNk;
    }

    public Knjiga getIdKnjiga() {
        return idKnjiga;
    }

    public void setIdKnjiga(Knjiga idKnjiga) {
        this.idKnjiga = idKnjiga;
    }

    public Autor getIdAutor() {
        return idAutor;
    }

    public void setIdAutor(Autor idAutor) {
        this.idAutor = idAutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idNk != null ? idNk.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Napisanaknjiga)) {
            return false;
        }
        Napisanaknjiga other = (Napisanaknjiga) object;
        if ((this.idNk == null && other.idNk != null) || (this.idNk != null && !this.idNk.equals(other.idNk))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rs.ac.metropolitan.jpa.entity.Napisanaknjiga[ idNk=" + idNk + " ]";
    }
    
}

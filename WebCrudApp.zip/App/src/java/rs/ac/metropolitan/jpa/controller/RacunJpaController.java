/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import rs.ac.metropolitan.jpa.entity.Korisnik;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.IllegalOrphanException;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Racun;

/**
 *
 * @author MSI
 */
public class RacunJpaController implements Serializable {

    public RacunJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Racun racun) throws RollbackFailureException, Exception {
        if (racun.getKorisnikCollection() == null) {
            racun.setKorisnikCollection(new ArrayList<Korisnik>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<Korisnik> attachedKorisnikCollection = new ArrayList<Korisnik>();
            for (Korisnik korisnikCollectionKorisnikToAttach : racun.getKorisnikCollection()) {
                korisnikCollectionKorisnikToAttach = em.getReference(korisnikCollectionKorisnikToAttach.getClass(), korisnikCollectionKorisnikToAttach.getIdKorisnik());
                attachedKorisnikCollection.add(korisnikCollectionKorisnikToAttach);
            }
            racun.setKorisnikCollection(attachedKorisnikCollection);
            em.persist(racun);
            for (Korisnik korisnikCollectionKorisnik : racun.getKorisnikCollection()) {
                Racun oldIdRacunOfKorisnikCollectionKorisnik = korisnikCollectionKorisnik.getIdRacun();
                korisnikCollectionKorisnik.setIdRacun(racun);
                korisnikCollectionKorisnik = em.merge(korisnikCollectionKorisnik);
                if (oldIdRacunOfKorisnikCollectionKorisnik != null) {
                    oldIdRacunOfKorisnikCollectionKorisnik.getKorisnikCollection().remove(korisnikCollectionKorisnik);
                    oldIdRacunOfKorisnikCollectionKorisnik = em.merge(oldIdRacunOfKorisnikCollectionKorisnik);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Racun racun) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Racun persistentRacun = em.find(Racun.class, racun.getIdRacun());
            Collection<Korisnik> korisnikCollectionOld = persistentRacun.getKorisnikCollection();
            Collection<Korisnik> korisnikCollectionNew = racun.getKorisnikCollection();
            List<String> illegalOrphanMessages = null;
            for (Korisnik korisnikCollectionOldKorisnik : korisnikCollectionOld) {
                if (!korisnikCollectionNew.contains(korisnikCollectionOldKorisnik)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Korisnik " + korisnikCollectionOldKorisnik + " since its idRacun field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Korisnik> attachedKorisnikCollectionNew = new ArrayList<Korisnik>();
            for (Korisnik korisnikCollectionNewKorisnikToAttach : korisnikCollectionNew) {
                korisnikCollectionNewKorisnikToAttach = em.getReference(korisnikCollectionNewKorisnikToAttach.getClass(), korisnikCollectionNewKorisnikToAttach.getIdKorisnik());
                attachedKorisnikCollectionNew.add(korisnikCollectionNewKorisnikToAttach);
            }
            korisnikCollectionNew = attachedKorisnikCollectionNew;
            racun.setKorisnikCollection(korisnikCollectionNew);
            racun = em.merge(racun);
            for (Korisnik korisnikCollectionNewKorisnik : korisnikCollectionNew) {
                if (!korisnikCollectionOld.contains(korisnikCollectionNewKorisnik)) {
                    Racun oldIdRacunOfKorisnikCollectionNewKorisnik = korisnikCollectionNewKorisnik.getIdRacun();
                    korisnikCollectionNewKorisnik.setIdRacun(racun);
                    korisnikCollectionNewKorisnik = em.merge(korisnikCollectionNewKorisnik);
                    if (oldIdRacunOfKorisnikCollectionNewKorisnik != null && !oldIdRacunOfKorisnikCollectionNewKorisnik.equals(racun)) {
                        oldIdRacunOfKorisnikCollectionNewKorisnik.getKorisnikCollection().remove(korisnikCollectionNewKorisnik);
                        oldIdRacunOfKorisnikCollectionNewKorisnik = em.merge(oldIdRacunOfKorisnikCollectionNewKorisnik);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = racun.getIdRacun();
                if (findRacun(id) == null) {
                    throw new NonexistentEntityException("The racun with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Racun racun;
            try {
                racun = em.getReference(Racun.class, id);
                racun.getIdRacun();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The racun with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Korisnik> korisnikCollectionOrphanCheck = racun.getKorisnikCollection();
            for (Korisnik korisnikCollectionOrphanCheckKorisnik : korisnikCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Racun (" + racun + ") cannot be destroyed since the Korisnik " + korisnikCollectionOrphanCheckKorisnik + " in its korisnikCollection field has a non-nullable idRacun field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(racun);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Racun> findRacunEntities() {
        return findRacunEntities(true, -1, -1);
    }

    public List<Racun> findRacunEntities(int maxResults, int firstResult) {
        return findRacunEntities(false, maxResults, firstResult);
    }

    private List<Racun> findRacunEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Racun.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Racun findRacun(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Racun.class, id);
        } finally {
            em.close();
        }
    }

    public int getRacunCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Racun> rt = cq.from(Racun.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

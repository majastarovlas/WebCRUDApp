package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Admin;
import rs.ac.metropolitan.jpa.entity.Korisnik;

public class AdminJpaController implements Serializable {

    public AdminJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Admin admin) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik idKorisnik = admin.getIdKorisnik();
            if (idKorisnik != null) {
                idKorisnik = em.getReference(idKorisnik.getClass(), idKorisnik.getIdKorisnik());
                admin.setIdKorisnik(idKorisnik);
            }
            em.persist(admin);
            if (idKorisnik != null) {
                idKorisnik.getAdminCollection().add(admin);
                idKorisnik = em.merge(idKorisnik);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Admin admin) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Admin persistentAdmin = em.find(Admin.class, admin.getIdAdmin());
            Korisnik idKorisnikOld = persistentAdmin.getIdKorisnik();
            Korisnik idKorisnikNew = admin.getIdKorisnik();
            if (idKorisnikNew != null) {
                idKorisnikNew = em.getReference(idKorisnikNew.getClass(), idKorisnikNew.getIdKorisnik());
                admin.setIdKorisnik(idKorisnikNew);
            }
            admin = em.merge(admin);
            if (idKorisnikOld != null && !idKorisnikOld.equals(idKorisnikNew)) {
                idKorisnikOld.getAdminCollection().remove(admin);
                idKorisnikOld = em.merge(idKorisnikOld);
            }
            if (idKorisnikNew != null && !idKorisnikNew.equals(idKorisnikOld)) {
                idKorisnikNew.getAdminCollection().add(admin);
                idKorisnikNew = em.merge(idKorisnikNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = admin.getIdAdmin();
                if (findAdmin(id) == null) {
                    throw new NonexistentEntityException("The admin with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Admin admin;
            try {
                admin = em.getReference(Admin.class, id);
                admin.getIdAdmin();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The admin with id " + id + " no longer exists.", enfe);
            }
            Korisnik idKorisnik = admin.getIdKorisnik();
            if (idKorisnik != null) {
                idKorisnik.getAdminCollection().remove(admin);
                idKorisnik = em.merge(idKorisnik);
            }
            em.remove(admin);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Admin> findAdminEntities() {
        return findAdminEntities(true, -1, -1);
    }

    public List<Admin> findAdminEntities(int maxResults, int firstResult) {
        return findAdminEntities(false, maxResults, firstResult);
    }

    private List<Admin> findAdminEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Admin.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Admin findAdmin(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Admin.class, id);
        } finally {
            em.close();
        }
    }

    public int getAdminCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Admin> rt = cq.from(Admin.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

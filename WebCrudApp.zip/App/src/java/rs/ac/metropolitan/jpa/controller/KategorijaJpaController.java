/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import rs.ac.metropolitan.jpa.entity.Knjiga;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.IllegalOrphanException;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Kategorija;

/**
 *
 * @author MSI
 */
public class KategorijaJpaController implements Serializable {

    public KategorijaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Kategorija kategorija) throws RollbackFailureException, Exception {
        if (kategorija.getKnjigaCollection() == null) {
            kategorija.setKnjigaCollection(new ArrayList<Knjiga>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<Knjiga> attachedKnjigaCollection = new ArrayList<Knjiga>();
            for (Knjiga knjigaCollectionKnjigaToAttach : kategorija.getKnjigaCollection()) {
                knjigaCollectionKnjigaToAttach = em.getReference(knjigaCollectionKnjigaToAttach.getClass(), knjigaCollectionKnjigaToAttach.getIdKnjiga());
                attachedKnjigaCollection.add(knjigaCollectionKnjigaToAttach);
            }
            kategorija.setKnjigaCollection(attachedKnjigaCollection);
            em.persist(kategorija);
            for (Knjiga knjigaCollectionKnjiga : kategorija.getKnjigaCollection()) {
                Kategorija oldIdKatOfKnjigaCollectionKnjiga = knjigaCollectionKnjiga.getIdKat();
                knjigaCollectionKnjiga.setIdKat(kategorija);
                knjigaCollectionKnjiga = em.merge(knjigaCollectionKnjiga);
                if (oldIdKatOfKnjigaCollectionKnjiga != null) {
                    oldIdKatOfKnjigaCollectionKnjiga.getKnjigaCollection().remove(knjigaCollectionKnjiga);
                    oldIdKatOfKnjigaCollectionKnjiga = em.merge(oldIdKatOfKnjigaCollectionKnjiga);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Kategorija kategorija) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Kategorija persistentKategorija = em.find(Kategorija.class, kategorija.getIdKat());
            Collection<Knjiga> knjigaCollectionOld = persistentKategorija.getKnjigaCollection();
            Collection<Knjiga> knjigaCollectionNew = kategorija.getKnjigaCollection();
            List<String> illegalOrphanMessages = null;
            for (Knjiga knjigaCollectionOldKnjiga : knjigaCollectionOld) {
                if (!knjigaCollectionNew.contains(knjigaCollectionOldKnjiga)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Knjiga " + knjigaCollectionOldKnjiga + " since its idKat field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Knjiga> attachedKnjigaCollectionNew = new ArrayList<Knjiga>();
            for (Knjiga knjigaCollectionNewKnjigaToAttach : knjigaCollectionNew) {
                knjigaCollectionNewKnjigaToAttach = em.getReference(knjigaCollectionNewKnjigaToAttach.getClass(), knjigaCollectionNewKnjigaToAttach.getIdKnjiga());
                attachedKnjigaCollectionNew.add(knjigaCollectionNewKnjigaToAttach);
            }
            knjigaCollectionNew = attachedKnjigaCollectionNew;
            kategorija.setKnjigaCollection(knjigaCollectionNew);
            kategorija = em.merge(kategorija);
            for (Knjiga knjigaCollectionNewKnjiga : knjigaCollectionNew) {
                if (!knjigaCollectionOld.contains(knjigaCollectionNewKnjiga)) {
                    Kategorija oldIdKatOfKnjigaCollectionNewKnjiga = knjigaCollectionNewKnjiga.getIdKat();
                    knjigaCollectionNewKnjiga.setIdKat(kategorija);
                    knjigaCollectionNewKnjiga = em.merge(knjigaCollectionNewKnjiga);
                    if (oldIdKatOfKnjigaCollectionNewKnjiga != null && !oldIdKatOfKnjigaCollectionNewKnjiga.equals(kategorija)) {
                        oldIdKatOfKnjigaCollectionNewKnjiga.getKnjigaCollection().remove(knjigaCollectionNewKnjiga);
                        oldIdKatOfKnjigaCollectionNewKnjiga = em.merge(oldIdKatOfKnjigaCollectionNewKnjiga);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = kategorija.getIdKat();
                if (findKategorija(id) == null) {
                    throw new NonexistentEntityException("The kategorija with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Kategorija kategorija;
            try {
                kategorija = em.getReference(Kategorija.class, id);
                kategorija.getIdKat();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The kategorija with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Knjiga> knjigaCollectionOrphanCheck = kategorija.getKnjigaCollection();
            for (Knjiga knjigaCollectionOrphanCheckKnjiga : knjigaCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Kategorija (" + kategorija + ") cannot be destroyed since the Knjiga " + knjigaCollectionOrphanCheckKnjiga + " in its knjigaCollection field has a non-nullable idKat field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(kategorija);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Kategorija> findKategorijaEntities() {
        return findKategorijaEntities(true, -1, -1);
    }

    public List<Kategorija> findKategorijaEntities(int maxResults, int firstResult) {
        return findKategorijaEntities(false, maxResults, firstResult);
    }

    private List<Kategorija> findKategorijaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Kategorija.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Kategorija findKategorija(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Kategorija.class, id);
        } finally {
            em.close();
        }
    }

    public int getKategorijaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Kategorija> rt = cq.from(Kategorija.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author MSI
 */
@Entity
@Table(name = "korisnik")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Korisnik.findAll", query = "SELECT k FROM Korisnik k")
    , @NamedQuery(name = "Korisnik.findByIdKorisnik", query = "SELECT k FROM Korisnik k WHERE k.idKorisnik = :idKorisnik")
    , @NamedQuery(name = "Korisnik.findByImeKorisnik", query = "SELECT k FROM Korisnik k WHERE k.imeKorisnik = :imeKorisnik")
    , @NamedQuery(name = "Korisnik.findByPrezimeKorisnik", query = "SELECT k FROM Korisnik k WHERE k.prezimeKorisnik = :prezimeKorisnik")
    , @NamedQuery(name = "Korisnik.findByEmailKorisnik", query = "SELECT k FROM Korisnik k WHERE k.emailKorisnik = :emailKorisnik")
    , @NamedQuery(name = "Korisnik.findByPassword", query = "SELECT k FROM Korisnik k WHERE k.password = :password")})
public class Korisnik implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_KORISNIK")
    private Integer idKorisnik;
    @Size(max = 50)
    @Column(name = "IME_KORISNIK")
    private String imeKorisnik;
    @Size(max = 50)
    @Column(name = "PREZIME_KORISNIK")
    private String prezimeKorisnik;
    @Size(max = 50)
    @Column(name = "EMAIL_KORISNIK")
    private String emailKorisnik;
    @Size(max = 50)
    @Column(name = "PASSWORD")
    private String password;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idKorisnik")
    private Collection<Sacuvanaknjiga> sacuvanaknjigaCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idKorisnik")
    private Collection<Admin> adminCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idKorisnik")
    private Collection<Ocena> ocenaCollection;
    @JoinColumn(name = "ID_RACUN", referencedColumnName = "ID_RACUN")
    @ManyToOne(optional = false)
    private Racun idRacun;

    public Korisnik() {
    }

    public Korisnik(Integer idKorisnik) {
        this.idKorisnik = idKorisnik;
    }

    public Integer getIdKorisnik() {
        return idKorisnik;
    }

    public void setIdKorisnik(Integer idKorisnik) {
        this.idKorisnik = idKorisnik;
    }

    public String getImeKorisnik() {
        return imeKorisnik;
    }

    public void setImeKorisnik(String imeKorisnik) {
        this.imeKorisnik = imeKorisnik;
    }

    public String getPrezimeKorisnik() {
        return prezimeKorisnik;
    }

    public void setPrezimeKorisnik(String prezimeKorisnik) {
        this.prezimeKorisnik = prezimeKorisnik;
    }

    public String getEmailKorisnik() {
        return emailKorisnik;
    }

    public void setEmailKorisnik(String emailKorisnik) {
        this.emailKorisnik = emailKorisnik;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @XmlTransient
    public Collection<Sacuvanaknjiga> getSacuvanaknjigaCollection() {
        return sacuvanaknjigaCollection;
    }

    public void setSacuvanaknjigaCollection(Collection<Sacuvanaknjiga> sacuvanaknjigaCollection) {
        this.sacuvanaknjigaCollection = sacuvanaknjigaCollection;
    }

    @XmlTransient
    public Collection<Admin> getAdminCollection() {
        return adminCollection;
    }

    public void setAdminCollection(Collection<Admin> adminCollection) {
        this.adminCollection = adminCollection;
    }

    @XmlTransient
    public Collection<Ocena> getOcenaCollection() {
        return ocenaCollection;
    }

    public void setOcenaCollection(Collection<Ocena> ocenaCollection) {
        this.ocenaCollection = ocenaCollection;
    }

    public Racun getIdRacun() {
        return idRacun;
    }

    public void setIdRacun(Racun idRacun) {
        this.idRacun = idRacun;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idKorisnik != null ? idKorisnik.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Korisnik)) {
            return false;
        }
        Korisnik other = (Korisnik) object;
        if ((this.idKorisnik == null && other.idKorisnik != null) || (this.idKorisnik != null && !this.idKorisnik.equals(other.idKorisnik))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rs.ac.metropolitan.jpa.entity.Korisnik[ idKorisnik=" + idKorisnik + " ]";
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import rs.ac.metropolitan.jpa.entity.Racun;
import rs.ac.metropolitan.jpa.entity.Sacuvanaknjiga;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.IllegalOrphanException;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Admin;
import rs.ac.metropolitan.jpa.entity.Korisnik;
import rs.ac.metropolitan.jpa.entity.Ocena;

/**
 *
 * @author MSI
 */
public class KorisnikJpaController implements Serializable {

    public KorisnikJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Korisnik korisnik) throws RollbackFailureException, Exception {
        if (korisnik.getSacuvanaknjigaCollection() == null) {
            korisnik.setSacuvanaknjigaCollection(new ArrayList<Sacuvanaknjiga>());
        }
        if (korisnik.getAdminCollection() == null) {
            korisnik.setAdminCollection(new ArrayList<Admin>());
        }
        if (korisnik.getOcenaCollection() == null) {
            korisnik.setOcenaCollection(new ArrayList<Ocena>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Racun idRacun = korisnik.getIdRacun();
            if (idRacun != null) {
                idRacun = em.getReference(idRacun.getClass(), idRacun.getIdRacun());
                korisnik.setIdRacun(idRacun);
            }
            Collection<Sacuvanaknjiga> attachedSacuvanaknjigaCollection = new ArrayList<Sacuvanaknjiga>();
            for (Sacuvanaknjiga sacuvanaknjigaCollectionSacuvanaknjigaToAttach : korisnik.getSacuvanaknjigaCollection()) {
                sacuvanaknjigaCollectionSacuvanaknjigaToAttach = em.getReference(sacuvanaknjigaCollectionSacuvanaknjigaToAttach.getClass(), sacuvanaknjigaCollectionSacuvanaknjigaToAttach.getIdSk());
                attachedSacuvanaknjigaCollection.add(sacuvanaknjigaCollectionSacuvanaknjigaToAttach);
            }
            korisnik.setSacuvanaknjigaCollection(attachedSacuvanaknjigaCollection);
            Collection<Admin> attachedAdminCollection = new ArrayList<Admin>();
            for (Admin adminCollectionAdminToAttach : korisnik.getAdminCollection()) {
                adminCollectionAdminToAttach = em.getReference(adminCollectionAdminToAttach.getClass(), adminCollectionAdminToAttach.getIdAdmin());
                attachedAdminCollection.add(adminCollectionAdminToAttach);
            }
            korisnik.setAdminCollection(attachedAdminCollection);
            Collection<Ocena> attachedOcenaCollection = new ArrayList<Ocena>();
            for (Ocena ocenaCollectionOcenaToAttach : korisnik.getOcenaCollection()) {
                ocenaCollectionOcenaToAttach = em.getReference(ocenaCollectionOcenaToAttach.getClass(), ocenaCollectionOcenaToAttach.getIdOcena());
                attachedOcenaCollection.add(ocenaCollectionOcenaToAttach);
            }
            korisnik.setOcenaCollection(attachedOcenaCollection);
            em.persist(korisnik);
            if (idRacun != null) {
                idRacun.getKorisnikCollection().add(korisnik);
                idRacun = em.merge(idRacun);
            }
            for (Sacuvanaknjiga sacuvanaknjigaCollectionSacuvanaknjiga : korisnik.getSacuvanaknjigaCollection()) {
                Korisnik oldIdKorisnikOfSacuvanaknjigaCollectionSacuvanaknjiga = sacuvanaknjigaCollectionSacuvanaknjiga.getIdKorisnik();
                sacuvanaknjigaCollectionSacuvanaknjiga.setIdKorisnik(korisnik);
                sacuvanaknjigaCollectionSacuvanaknjiga = em.merge(sacuvanaknjigaCollectionSacuvanaknjiga);
                if (oldIdKorisnikOfSacuvanaknjigaCollectionSacuvanaknjiga != null) {
                    oldIdKorisnikOfSacuvanaknjigaCollectionSacuvanaknjiga.getSacuvanaknjigaCollection().remove(sacuvanaknjigaCollectionSacuvanaknjiga);
                    oldIdKorisnikOfSacuvanaknjigaCollectionSacuvanaknjiga = em.merge(oldIdKorisnikOfSacuvanaknjigaCollectionSacuvanaknjiga);
                }
            }
            for (Admin adminCollectionAdmin : korisnik.getAdminCollection()) {
                Korisnik oldIdKorisnikOfAdminCollectionAdmin = adminCollectionAdmin.getIdKorisnik();
                adminCollectionAdmin.setIdKorisnik(korisnik);
                adminCollectionAdmin = em.merge(adminCollectionAdmin);
                if (oldIdKorisnikOfAdminCollectionAdmin != null) {
                    oldIdKorisnikOfAdminCollectionAdmin.getAdminCollection().remove(adminCollectionAdmin);
                    oldIdKorisnikOfAdminCollectionAdmin = em.merge(oldIdKorisnikOfAdminCollectionAdmin);
                }
            }
            for (Ocena ocenaCollectionOcena : korisnik.getOcenaCollection()) {
                Korisnik oldIdKorisnikOfOcenaCollectionOcena = ocenaCollectionOcena.getIdKorisnik();
                ocenaCollectionOcena.setIdKorisnik(korisnik);
                ocenaCollectionOcena = em.merge(ocenaCollectionOcena);
                if (oldIdKorisnikOfOcenaCollectionOcena != null) {
                    oldIdKorisnikOfOcenaCollectionOcena.getOcenaCollection().remove(ocenaCollectionOcena);
                    oldIdKorisnikOfOcenaCollectionOcena = em.merge(oldIdKorisnikOfOcenaCollectionOcena);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Korisnik korisnik) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik persistentKorisnik = em.find(Korisnik.class, korisnik.getIdKorisnik());
            Racun idRacunOld = persistentKorisnik.getIdRacun();
            Racun idRacunNew = korisnik.getIdRacun();
            Collection<Sacuvanaknjiga> sacuvanaknjigaCollectionOld = persistentKorisnik.getSacuvanaknjigaCollection();
            Collection<Sacuvanaknjiga> sacuvanaknjigaCollectionNew = korisnik.getSacuvanaknjigaCollection();
            Collection<Admin> adminCollectionOld = persistentKorisnik.getAdminCollection();
            Collection<Admin> adminCollectionNew = korisnik.getAdminCollection();
            Collection<Ocena> ocenaCollectionOld = persistentKorisnik.getOcenaCollection();
            Collection<Ocena> ocenaCollectionNew = korisnik.getOcenaCollection();
            List<String> illegalOrphanMessages = null;
            for (Sacuvanaknjiga sacuvanaknjigaCollectionOldSacuvanaknjiga : sacuvanaknjigaCollectionOld) {
                if (!sacuvanaknjigaCollectionNew.contains(sacuvanaknjigaCollectionOldSacuvanaknjiga)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Sacuvanaknjiga " + sacuvanaknjigaCollectionOldSacuvanaknjiga + " since its idKorisnik field is not nullable.");
                }
            }
            for (Admin adminCollectionOldAdmin : adminCollectionOld) {
                if (!adminCollectionNew.contains(adminCollectionOldAdmin)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Admin " + adminCollectionOldAdmin + " since its idKorisnik field is not nullable.");
                }
            }
            for (Ocena ocenaCollectionOldOcena : ocenaCollectionOld) {
                if (!ocenaCollectionNew.contains(ocenaCollectionOldOcena)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Ocena " + ocenaCollectionOldOcena + " since its idKorisnik field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (idRacunNew != null) {
                idRacunNew = em.getReference(idRacunNew.getClass(), idRacunNew.getIdRacun());
                korisnik.setIdRacun(idRacunNew);
            }
            Collection<Sacuvanaknjiga> attachedSacuvanaknjigaCollectionNew = new ArrayList<Sacuvanaknjiga>();
            for (Sacuvanaknjiga sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach : sacuvanaknjigaCollectionNew) {
                sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach = em.getReference(sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach.getClass(), sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach.getIdSk());
                attachedSacuvanaknjigaCollectionNew.add(sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach);
            }
            sacuvanaknjigaCollectionNew = attachedSacuvanaknjigaCollectionNew;
            korisnik.setSacuvanaknjigaCollection(sacuvanaknjigaCollectionNew);
            Collection<Admin> attachedAdminCollectionNew = new ArrayList<Admin>();
            for (Admin adminCollectionNewAdminToAttach : adminCollectionNew) {
                adminCollectionNewAdminToAttach = em.getReference(adminCollectionNewAdminToAttach.getClass(), adminCollectionNewAdminToAttach.getIdAdmin());
                attachedAdminCollectionNew.add(adminCollectionNewAdminToAttach);
            }
            adminCollectionNew = attachedAdminCollectionNew;
            korisnik.setAdminCollection(adminCollectionNew);
            Collection<Ocena> attachedOcenaCollectionNew = new ArrayList<Ocena>();
            for (Ocena ocenaCollectionNewOcenaToAttach : ocenaCollectionNew) {
                ocenaCollectionNewOcenaToAttach = em.getReference(ocenaCollectionNewOcenaToAttach.getClass(), ocenaCollectionNewOcenaToAttach.getIdOcena());
                attachedOcenaCollectionNew.add(ocenaCollectionNewOcenaToAttach);
            }
            ocenaCollectionNew = attachedOcenaCollectionNew;
            korisnik.setOcenaCollection(ocenaCollectionNew);
            korisnik = em.merge(korisnik);
            if (idRacunOld != null && !idRacunOld.equals(idRacunNew)) {
                idRacunOld.getKorisnikCollection().remove(korisnik);
                idRacunOld = em.merge(idRacunOld);
            }
            if (idRacunNew != null && !idRacunNew.equals(idRacunOld)) {
                idRacunNew.getKorisnikCollection().add(korisnik);
                idRacunNew = em.merge(idRacunNew);
            }
            for (Sacuvanaknjiga sacuvanaknjigaCollectionNewSacuvanaknjiga : sacuvanaknjigaCollectionNew) {
                if (!sacuvanaknjigaCollectionOld.contains(sacuvanaknjigaCollectionNewSacuvanaknjiga)) {
                    Korisnik oldIdKorisnikOfSacuvanaknjigaCollectionNewSacuvanaknjiga = sacuvanaknjigaCollectionNewSacuvanaknjiga.getIdKorisnik();
                    sacuvanaknjigaCollectionNewSacuvanaknjiga.setIdKorisnik(korisnik);
                    sacuvanaknjigaCollectionNewSacuvanaknjiga = em.merge(sacuvanaknjigaCollectionNewSacuvanaknjiga);
                    if (oldIdKorisnikOfSacuvanaknjigaCollectionNewSacuvanaknjiga != null && !oldIdKorisnikOfSacuvanaknjigaCollectionNewSacuvanaknjiga.equals(korisnik)) {
                        oldIdKorisnikOfSacuvanaknjigaCollectionNewSacuvanaknjiga.getSacuvanaknjigaCollection().remove(sacuvanaknjigaCollectionNewSacuvanaknjiga);
                        oldIdKorisnikOfSacuvanaknjigaCollectionNewSacuvanaknjiga = em.merge(oldIdKorisnikOfSacuvanaknjigaCollectionNewSacuvanaknjiga);
                    }
                }
            }
            for (Admin adminCollectionNewAdmin : adminCollectionNew) {
                if (!adminCollectionOld.contains(adminCollectionNewAdmin)) {
                    Korisnik oldIdKorisnikOfAdminCollectionNewAdmin = adminCollectionNewAdmin.getIdKorisnik();
                    adminCollectionNewAdmin.setIdKorisnik(korisnik);
                    adminCollectionNewAdmin = em.merge(adminCollectionNewAdmin);
                    if (oldIdKorisnikOfAdminCollectionNewAdmin != null && !oldIdKorisnikOfAdminCollectionNewAdmin.equals(korisnik)) {
                        oldIdKorisnikOfAdminCollectionNewAdmin.getAdminCollection().remove(adminCollectionNewAdmin);
                        oldIdKorisnikOfAdminCollectionNewAdmin = em.merge(oldIdKorisnikOfAdminCollectionNewAdmin);
                    }
                }
            }
            for (Ocena ocenaCollectionNewOcena : ocenaCollectionNew) {
                if (!ocenaCollectionOld.contains(ocenaCollectionNewOcena)) {
                    Korisnik oldIdKorisnikOfOcenaCollectionNewOcena = ocenaCollectionNewOcena.getIdKorisnik();
                    ocenaCollectionNewOcena.setIdKorisnik(korisnik);
                    ocenaCollectionNewOcena = em.merge(ocenaCollectionNewOcena);
                    if (oldIdKorisnikOfOcenaCollectionNewOcena != null && !oldIdKorisnikOfOcenaCollectionNewOcena.equals(korisnik)) {
                        oldIdKorisnikOfOcenaCollectionNewOcena.getOcenaCollection().remove(ocenaCollectionNewOcena);
                        oldIdKorisnikOfOcenaCollectionNewOcena = em.merge(oldIdKorisnikOfOcenaCollectionNewOcena);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = korisnik.getIdKorisnik();
                if (findKorisnik(id) == null) {
                    throw new NonexistentEntityException("The korisnik with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik korisnik;
            try {
                korisnik = em.getReference(Korisnik.class, id);
                korisnik.getIdKorisnik();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The korisnik with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Sacuvanaknjiga> sacuvanaknjigaCollectionOrphanCheck = korisnik.getSacuvanaknjigaCollection();
            for (Sacuvanaknjiga sacuvanaknjigaCollectionOrphanCheckSacuvanaknjiga : sacuvanaknjigaCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Korisnik (" + korisnik + ") cannot be destroyed since the Sacuvanaknjiga " + sacuvanaknjigaCollectionOrphanCheckSacuvanaknjiga + " in its sacuvanaknjigaCollection field has a non-nullable idKorisnik field.");
            }
            Collection<Admin> adminCollectionOrphanCheck = korisnik.getAdminCollection();
            for (Admin adminCollectionOrphanCheckAdmin : adminCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Korisnik (" + korisnik + ") cannot be destroyed since the Admin " + adminCollectionOrphanCheckAdmin + " in its adminCollection field has a non-nullable idKorisnik field.");
            }
            Collection<Ocena> ocenaCollectionOrphanCheck = korisnik.getOcenaCollection();
            for (Ocena ocenaCollectionOrphanCheckOcena : ocenaCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Korisnik (" + korisnik + ") cannot be destroyed since the Ocena " + ocenaCollectionOrphanCheckOcena + " in its ocenaCollection field has a non-nullable idKorisnik field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Racun idRacun = korisnik.getIdRacun();
            if (idRacun != null) {
                idRacun.getKorisnikCollection().remove(korisnik);
                idRacun = em.merge(idRacun);
            }
            em.remove(korisnik);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Korisnik> findKorisnikEntities() {
        return findKorisnikEntities(true, -1, -1);
    }

    public List<Korisnik> findKorisnikEntities(int maxResults, int firstResult) {
        return findKorisnikEntities(false, maxResults, firstResult);
    }

    private List<Korisnik> findKorisnikEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Korisnik.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Korisnik findKorisnik(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Korisnik.class, id);
        } finally {
            em.close();
        }
    }

    public int getKorisnikCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Korisnik> rt = cq.from(Korisnik.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author MSI
 */
@Entity
@Table(name = "racun")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Racun.findAll", query = "SELECT r FROM Racun r")
    , @NamedQuery(name = "Racun.findByIdRacun", query = "SELECT r FROM Racun r WHERE r.idRacun = :idRacun")
    , @NamedQuery(name = "Racun.findByBrojKartica", query = "SELECT r FROM Racun r WHERE r.brojKartica = :brojKartica")
    , @NamedQuery(name = "Racun.findByDatumVazenja", query = "SELECT r FROM Racun r WHERE r.datumVazenja = :datumVazenja")
    , @NamedQuery(name = "Racun.findByCvv", query = "SELECT r FROM Racun r WHERE r.cvv = :cvv")})
public class Racun implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_RACUN")
    private Integer idRacun;
    @Size(max = 100)
    @Column(name = "BROJ_KARTICA")
    private String brojKartica;
    @Size(max = 10)
    @Column(name = "DATUM_VAZENJA")
    private String datumVazenja;
    @Size(max = 10)
    @Column(name = "CVV")
    private String cvv;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idRacun")
    private Collection<Korisnik> korisnikCollection;

    public Racun() {
    }

    public Racun(Integer idRacun) {
        this.idRacun = idRacun;
    }

    public Integer getIdRacun() {
        return idRacun;
    }

    public void setIdRacun(Integer idRacun) {
        this.idRacun = idRacun;
    }

    public String getBrojKartica() {
        return brojKartica;
    }

    public void setBrojKartica(String brojKartica) {
        this.brojKartica = brojKartica;
    }

    public String getDatumVazenja() {
        return datumVazenja;
    }

    public void setDatumVazenja(String datumVazenja) {
        this.datumVazenja = datumVazenja;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    @XmlTransient
    public Collection<Korisnik> getKorisnikCollection() {
        return korisnikCollection;
    }

    public void setKorisnikCollection(Collection<Korisnik> korisnikCollection) {
        this.korisnikCollection = korisnikCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRacun != null ? idRacun.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Racun)) {
            return false;
        }
        Racun other = (Racun) object;
        if ((this.idRacun == null && other.idRacun != null) || (this.idRacun != null && !this.idRacun.equals(other.idRacun))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rs.ac.metropolitan.jpa.entity.Racun[ idRacun=" + idRacun + " ]";
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author MSI
 */
@Entity
@Table(name = "knjiga")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Knjiga.findAll", query = "SELECT k FROM Knjiga k")
    , @NamedQuery(name = "Knjiga.findByIdKnjiga", query = "SELECT k FROM Knjiga k WHERE k.idKnjiga = :idKnjiga")
    , @NamedQuery(name = "Knjiga.findByIsbn", query = "SELECT k FROM Knjiga k WHERE k.isbn = :isbn")
    , @NamedQuery(name = "Knjiga.findByNazivKnjiga", query = "SELECT k FROM Knjiga k WHERE k.nazivKnjiga = :nazivKnjiga")
    , @NamedQuery(name = "Knjiga.findByLinkKnjiga", query = "SELECT k FROM Knjiga k WHERE k.linkKnjiga = :linkKnjiga")
    , @NamedQuery(name = "Knjiga.findBySlikaKnjiga", query = "SELECT k FROM Knjiga k WHERE k.slikaKnjiga = :slikaKnjiga")
    , @NamedQuery(name = "Knjiga.findByDatumKnjiga", query = "SELECT k FROM Knjiga k WHERE k.datumKnjiga = :datumKnjiga")
    , @NamedQuery(name = "Knjiga.findByOpisKnjiga", query = "SELECT k FROM Knjiga k WHERE k.opisKnjiga = :opisKnjiga")})
public class Knjiga implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_KNJIGA")
    private Integer idKnjiga;
    @Size(max = 30)
    @Column(name = "ISBN")
    private String isbn;
    @Size(max = 30)
    @Column(name = "NAZIV_KNJIGA")
    private String nazivKnjiga;
    @Size(max = 255)
    @Column(name = "LINK_KNJIGA")
    private String linkKnjiga;
    @Size(max = 255)
    @Column(name = "SLIKA_KNJIGA")
    private String slikaKnjiga;
    @Column(name = "DATUM_KNJIGA")
    @Temporal(TemporalType.DATE)
    private Date datumKnjiga;
    @Size(max = 255)
    @Column(name = "OPIS_KNJIGA")
    private String opisKnjiga;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idKnjiga")
    private Collection<Sacuvanaknjiga> sacuvanaknjigaCollection;
    @JoinColumn(name = "ID_KAT", referencedColumnName = "ID_KAT")
    @ManyToOne(optional = false)
    private Kategorija idKat;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idKnjiga")
    private Collection<Napisanaknjiga> napisanaknjigaCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idKnjiga")
    private Collection<Ocena> ocenaCollection;

    public Knjiga() {
    }

    public Knjiga(Integer idKnjiga) {
        this.idKnjiga = idKnjiga;
    }

    public Integer getIdKnjiga() {
        return idKnjiga;
    }

    public void setIdKnjiga(Integer idKnjiga) {
        this.idKnjiga = idKnjiga;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getNazivKnjiga() {
        return nazivKnjiga;
    }

    public void setNazivKnjiga(String nazivKnjiga) {
        this.nazivKnjiga = nazivKnjiga;
    }

    public String getLinkKnjiga() {
        return linkKnjiga;
    }

    public void setLinkKnjiga(String linkKnjiga) {
        this.linkKnjiga = linkKnjiga;
    }

    public String getSlikaKnjiga() {
        return slikaKnjiga;
    }

    public void setSlikaKnjiga(String slikaKnjiga) {
        this.slikaKnjiga = slikaKnjiga;
    }

    public Date getDatumKnjiga() {
        return datumKnjiga;
    }

    public void setDatumKnjiga(Date datumKnjiga) {
        this.datumKnjiga = datumKnjiga;
    }

    public String getOpisKnjiga() {
        return opisKnjiga;
    }

    public void setOpisKnjiga(String opisKnjiga) {
        this.opisKnjiga = opisKnjiga;
    }

    @XmlTransient
    public Collection<Sacuvanaknjiga> getSacuvanaknjigaCollection() {
        return sacuvanaknjigaCollection;
    }

    public void setSacuvanaknjigaCollection(Collection<Sacuvanaknjiga> sacuvanaknjigaCollection) {
        this.sacuvanaknjigaCollection = sacuvanaknjigaCollection;
    }

    public Kategorija getIdKat() {
        return idKat;
    }

    public void setIdKat(Kategorija idKat) {
        this.idKat = idKat;
    }

    @XmlTransient
    public Collection<Napisanaknjiga> getNapisanaknjigaCollection() {
        return napisanaknjigaCollection;
    }

    public void setNapisanaknjigaCollection(Collection<Napisanaknjiga> napisanaknjigaCollection) {
        this.napisanaknjigaCollection = napisanaknjigaCollection;
    }

    @XmlTransient
    public Collection<Ocena> getOcenaCollection() {
        return ocenaCollection;
    }

    public void setOcenaCollection(Collection<Ocena> ocenaCollection) {
        this.ocenaCollection = ocenaCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idKnjiga != null ? idKnjiga.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Knjiga)) {
            return false;
        }
        Knjiga other = (Knjiga) object;
        if ((this.idKnjiga == null && other.idKnjiga != null) || (this.idKnjiga != null && !this.idKnjiga.equals(other.idKnjiga))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "rs.ac.metropolitan.jpa.entity.Knjiga[ idKnjiga=" + idKnjiga + " ]";
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Korisnik;
import rs.ac.metropolitan.jpa.entity.Knjiga;
import rs.ac.metropolitan.jpa.entity.Ocena;

/**
 *
 * @author MSI
 */
public class OcenaJpaController implements Serializable {

    public OcenaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Ocena ocena) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik idKorisnik = ocena.getIdKorisnik();
            if (idKorisnik != null) {
                idKorisnik = em.getReference(idKorisnik.getClass(), idKorisnik.getIdKorisnik());
                ocena.setIdKorisnik(idKorisnik);
            }
            Knjiga idKnjiga = ocena.getIdKnjiga();
            if (idKnjiga != null) {
                idKnjiga = em.getReference(idKnjiga.getClass(), idKnjiga.getIdKnjiga());
                ocena.setIdKnjiga(idKnjiga);
            }
            em.persist(ocena);
            if (idKorisnik != null) {
                idKorisnik.getOcenaCollection().add(ocena);
                idKorisnik = em.merge(idKorisnik);
            }
            if (idKnjiga != null) {
                idKnjiga.getOcenaCollection().add(ocena);
                idKnjiga = em.merge(idKnjiga);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Ocena ocena) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Ocena persistentOcena = em.find(Ocena.class, ocena.getIdOcena());
            Korisnik idKorisnikOld = persistentOcena.getIdKorisnik();
            Korisnik idKorisnikNew = ocena.getIdKorisnik();
            Knjiga idKnjigaOld = persistentOcena.getIdKnjiga();
            Knjiga idKnjigaNew = ocena.getIdKnjiga();
            if (idKorisnikNew != null) {
                idKorisnikNew = em.getReference(idKorisnikNew.getClass(), idKorisnikNew.getIdKorisnik());
                ocena.setIdKorisnik(idKorisnikNew);
            }
            if (idKnjigaNew != null) {
                idKnjigaNew = em.getReference(idKnjigaNew.getClass(), idKnjigaNew.getIdKnjiga());
                ocena.setIdKnjiga(idKnjigaNew);
            }
            ocena = em.merge(ocena);
            if (idKorisnikOld != null && !idKorisnikOld.equals(idKorisnikNew)) {
                idKorisnikOld.getOcenaCollection().remove(ocena);
                idKorisnikOld = em.merge(idKorisnikOld);
            }
            if (idKorisnikNew != null && !idKorisnikNew.equals(idKorisnikOld)) {
                idKorisnikNew.getOcenaCollection().add(ocena);
                idKorisnikNew = em.merge(idKorisnikNew);
            }
            if (idKnjigaOld != null && !idKnjigaOld.equals(idKnjigaNew)) {
                idKnjigaOld.getOcenaCollection().remove(ocena);
                idKnjigaOld = em.merge(idKnjigaOld);
            }
            if (idKnjigaNew != null && !idKnjigaNew.equals(idKnjigaOld)) {
                idKnjigaNew.getOcenaCollection().add(ocena);
                idKnjigaNew = em.merge(idKnjigaNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = ocena.getIdOcena();
                if (findOcena(id) == null) {
                    throw new NonexistentEntityException("The ocena with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Ocena ocena;
            try {
                ocena = em.getReference(Ocena.class, id);
                ocena.getIdOcena();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The ocena with id " + id + " no longer exists.", enfe);
            }
            Korisnik idKorisnik = ocena.getIdKorisnik();
            if (idKorisnik != null) {
                idKorisnik.getOcenaCollection().remove(ocena);
                idKorisnik = em.merge(idKorisnik);
            }
            Knjiga idKnjiga = ocena.getIdKnjiga();
            if (idKnjiga != null) {
                idKnjiga.getOcenaCollection().remove(ocena);
                idKnjiga = em.merge(idKnjiga);
            }
            em.remove(ocena);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Ocena> findOcenaEntities() {
        return findOcenaEntities(true, -1, -1);
    }

    public List<Ocena> findOcenaEntities(int maxResults, int firstResult) {
        return findOcenaEntities(false, maxResults, firstResult);
    }

    private List<Ocena> findOcenaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Ocena.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Ocena findOcena(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Ocena.class, id);
        } finally {
            em.close();
        }
    }

    public int getOcenaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Ocena> rt = cq.from(Ocena.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

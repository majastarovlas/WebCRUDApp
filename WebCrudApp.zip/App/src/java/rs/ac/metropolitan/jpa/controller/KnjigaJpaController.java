/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import rs.ac.metropolitan.jpa.entity.Kategorija;
import rs.ac.metropolitan.jpa.entity.Sacuvanaknjiga;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.IllegalOrphanException;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Knjiga;
import rs.ac.metropolitan.jpa.entity.Napisanaknjiga;
import rs.ac.metropolitan.jpa.entity.Ocena;

/**
 *
 * @author MSI
 */
public class KnjigaJpaController implements Serializable {

    public KnjigaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Knjiga knjiga) throws RollbackFailureException, Exception {
        if (knjiga.getSacuvanaknjigaCollection() == null) {
            knjiga.setSacuvanaknjigaCollection(new ArrayList<Sacuvanaknjiga>());
        }
        if (knjiga.getNapisanaknjigaCollection() == null) {
            knjiga.setNapisanaknjigaCollection(new ArrayList<Napisanaknjiga>());
        }
        if (knjiga.getOcenaCollection() == null) {
            knjiga.setOcenaCollection(new ArrayList<Ocena>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Kategorija idKat = knjiga.getIdKat();
            if (idKat != null) {
                idKat = em.getReference(idKat.getClass(), idKat.getIdKat());
                knjiga.setIdKat(idKat);
            }
            Collection<Sacuvanaknjiga> attachedSacuvanaknjigaCollection = new ArrayList<Sacuvanaknjiga>();
            for (Sacuvanaknjiga sacuvanaknjigaCollectionSacuvanaknjigaToAttach : knjiga.getSacuvanaknjigaCollection()) {
                sacuvanaknjigaCollectionSacuvanaknjigaToAttach = em.getReference(sacuvanaknjigaCollectionSacuvanaknjigaToAttach.getClass(), sacuvanaknjigaCollectionSacuvanaknjigaToAttach.getIdSk());
                attachedSacuvanaknjigaCollection.add(sacuvanaknjigaCollectionSacuvanaknjigaToAttach);
            }
            knjiga.setSacuvanaknjigaCollection(attachedSacuvanaknjigaCollection);
            Collection<Napisanaknjiga> attachedNapisanaknjigaCollection = new ArrayList<Napisanaknjiga>();
            for (Napisanaknjiga napisanaknjigaCollectionNapisanaknjigaToAttach : knjiga.getNapisanaknjigaCollection()) {
                napisanaknjigaCollectionNapisanaknjigaToAttach = em.getReference(napisanaknjigaCollectionNapisanaknjigaToAttach.getClass(), napisanaknjigaCollectionNapisanaknjigaToAttach.getIdNk());
                attachedNapisanaknjigaCollection.add(napisanaknjigaCollectionNapisanaknjigaToAttach);
            }
            knjiga.setNapisanaknjigaCollection(attachedNapisanaknjigaCollection);
            Collection<Ocena> attachedOcenaCollection = new ArrayList<Ocena>();
            for (Ocena ocenaCollectionOcenaToAttach : knjiga.getOcenaCollection()) {
                ocenaCollectionOcenaToAttach = em.getReference(ocenaCollectionOcenaToAttach.getClass(), ocenaCollectionOcenaToAttach.getIdOcena());
                attachedOcenaCollection.add(ocenaCollectionOcenaToAttach);
            }
            knjiga.setOcenaCollection(attachedOcenaCollection);
            em.persist(knjiga);
            if (idKat != null) {
                idKat.getKnjigaCollection().add(knjiga);
                idKat = em.merge(idKat);
            }
            for (Sacuvanaknjiga sacuvanaknjigaCollectionSacuvanaknjiga : knjiga.getSacuvanaknjigaCollection()) {
                Knjiga oldIdKnjigaOfSacuvanaknjigaCollectionSacuvanaknjiga = sacuvanaknjigaCollectionSacuvanaknjiga.getIdKnjiga();
                sacuvanaknjigaCollectionSacuvanaknjiga.setIdKnjiga(knjiga);
                sacuvanaknjigaCollectionSacuvanaknjiga = em.merge(sacuvanaknjigaCollectionSacuvanaknjiga);
                if (oldIdKnjigaOfSacuvanaknjigaCollectionSacuvanaknjiga != null) {
                    oldIdKnjigaOfSacuvanaknjigaCollectionSacuvanaknjiga.getSacuvanaknjigaCollection().remove(sacuvanaknjigaCollectionSacuvanaknjiga);
                    oldIdKnjigaOfSacuvanaknjigaCollectionSacuvanaknjiga = em.merge(oldIdKnjigaOfSacuvanaknjigaCollectionSacuvanaknjiga);
                }
            }
            for (Napisanaknjiga napisanaknjigaCollectionNapisanaknjiga : knjiga.getNapisanaknjigaCollection()) {
                Knjiga oldIdKnjigaOfNapisanaknjigaCollectionNapisanaknjiga = napisanaknjigaCollectionNapisanaknjiga.getIdKnjiga();
                napisanaknjigaCollectionNapisanaknjiga.setIdKnjiga(knjiga);
                napisanaknjigaCollectionNapisanaknjiga = em.merge(napisanaknjigaCollectionNapisanaknjiga);
                if (oldIdKnjigaOfNapisanaknjigaCollectionNapisanaknjiga != null) {
                    oldIdKnjigaOfNapisanaknjigaCollectionNapisanaknjiga.getNapisanaknjigaCollection().remove(napisanaknjigaCollectionNapisanaknjiga);
                    oldIdKnjigaOfNapisanaknjigaCollectionNapisanaknjiga = em.merge(oldIdKnjigaOfNapisanaknjigaCollectionNapisanaknjiga);
                }
            }
            for (Ocena ocenaCollectionOcena : knjiga.getOcenaCollection()) {
                Knjiga oldIdKnjigaOfOcenaCollectionOcena = ocenaCollectionOcena.getIdKnjiga();
                ocenaCollectionOcena.setIdKnjiga(knjiga);
                ocenaCollectionOcena = em.merge(ocenaCollectionOcena);
                if (oldIdKnjigaOfOcenaCollectionOcena != null) {
                    oldIdKnjigaOfOcenaCollectionOcena.getOcenaCollection().remove(ocenaCollectionOcena);
                    oldIdKnjigaOfOcenaCollectionOcena = em.merge(oldIdKnjigaOfOcenaCollectionOcena);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Knjiga knjiga) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Knjiga persistentKnjiga = em.find(Knjiga.class, knjiga.getIdKnjiga());
            Kategorija idKatOld = persistentKnjiga.getIdKat();
            Kategorija idKatNew = knjiga.getIdKat();
            Collection<Sacuvanaknjiga> sacuvanaknjigaCollectionOld = persistentKnjiga.getSacuvanaknjigaCollection();
            Collection<Sacuvanaknjiga> sacuvanaknjigaCollectionNew = knjiga.getSacuvanaknjigaCollection();
            Collection<Napisanaknjiga> napisanaknjigaCollectionOld = persistentKnjiga.getNapisanaknjigaCollection();
            Collection<Napisanaknjiga> napisanaknjigaCollectionNew = knjiga.getNapisanaknjigaCollection();
            Collection<Ocena> ocenaCollectionOld = persistentKnjiga.getOcenaCollection();
            Collection<Ocena> ocenaCollectionNew = knjiga.getOcenaCollection();
            List<String> illegalOrphanMessages = null;
            for (Sacuvanaknjiga sacuvanaknjigaCollectionOldSacuvanaknjiga : sacuvanaknjigaCollectionOld) {
                if (!sacuvanaknjigaCollectionNew.contains(sacuvanaknjigaCollectionOldSacuvanaknjiga)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Sacuvanaknjiga " + sacuvanaknjigaCollectionOldSacuvanaknjiga + " since its idKnjiga field is not nullable.");
                }
            }
            for (Napisanaknjiga napisanaknjigaCollectionOldNapisanaknjiga : napisanaknjigaCollectionOld) {
                if (!napisanaknjigaCollectionNew.contains(napisanaknjigaCollectionOldNapisanaknjiga)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Napisanaknjiga " + napisanaknjigaCollectionOldNapisanaknjiga + " since its idKnjiga field is not nullable.");
                }
            }
            for (Ocena ocenaCollectionOldOcena : ocenaCollectionOld) {
                if (!ocenaCollectionNew.contains(ocenaCollectionOldOcena)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Ocena " + ocenaCollectionOldOcena + " since its idKnjiga field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (idKatNew != null) {
                idKatNew = em.getReference(idKatNew.getClass(), idKatNew.getIdKat());
                knjiga.setIdKat(idKatNew);
            }
            Collection<Sacuvanaknjiga> attachedSacuvanaknjigaCollectionNew = new ArrayList<Sacuvanaknjiga>();
            for (Sacuvanaknjiga sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach : sacuvanaknjigaCollectionNew) {
                sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach = em.getReference(sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach.getClass(), sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach.getIdSk());
                attachedSacuvanaknjigaCollectionNew.add(sacuvanaknjigaCollectionNewSacuvanaknjigaToAttach);
            }
            sacuvanaknjigaCollectionNew = attachedSacuvanaknjigaCollectionNew;
            knjiga.setSacuvanaknjigaCollection(sacuvanaknjigaCollectionNew);
            Collection<Napisanaknjiga> attachedNapisanaknjigaCollectionNew = new ArrayList<Napisanaknjiga>();
            for (Napisanaknjiga napisanaknjigaCollectionNewNapisanaknjigaToAttach : napisanaknjigaCollectionNew) {
                napisanaknjigaCollectionNewNapisanaknjigaToAttach = em.getReference(napisanaknjigaCollectionNewNapisanaknjigaToAttach.getClass(), napisanaknjigaCollectionNewNapisanaknjigaToAttach.getIdNk());
                attachedNapisanaknjigaCollectionNew.add(napisanaknjigaCollectionNewNapisanaknjigaToAttach);
            }
            napisanaknjigaCollectionNew = attachedNapisanaknjigaCollectionNew;
            knjiga.setNapisanaknjigaCollection(napisanaknjigaCollectionNew);
            Collection<Ocena> attachedOcenaCollectionNew = new ArrayList<Ocena>();
            for (Ocena ocenaCollectionNewOcenaToAttach : ocenaCollectionNew) {
                ocenaCollectionNewOcenaToAttach = em.getReference(ocenaCollectionNewOcenaToAttach.getClass(), ocenaCollectionNewOcenaToAttach.getIdOcena());
                attachedOcenaCollectionNew.add(ocenaCollectionNewOcenaToAttach);
            }
            ocenaCollectionNew = attachedOcenaCollectionNew;
            knjiga.setOcenaCollection(ocenaCollectionNew);
            knjiga = em.merge(knjiga);
            if (idKatOld != null && !idKatOld.equals(idKatNew)) {
                idKatOld.getKnjigaCollection().remove(knjiga);
                idKatOld = em.merge(idKatOld);
            }
            if (idKatNew != null && !idKatNew.equals(idKatOld)) {
                idKatNew.getKnjigaCollection().add(knjiga);
                idKatNew = em.merge(idKatNew);
            }
            for (Sacuvanaknjiga sacuvanaknjigaCollectionNewSacuvanaknjiga : sacuvanaknjigaCollectionNew) {
                if (!sacuvanaknjigaCollectionOld.contains(sacuvanaknjigaCollectionNewSacuvanaknjiga)) {
                    Knjiga oldIdKnjigaOfSacuvanaknjigaCollectionNewSacuvanaknjiga = sacuvanaknjigaCollectionNewSacuvanaknjiga.getIdKnjiga();
                    sacuvanaknjigaCollectionNewSacuvanaknjiga.setIdKnjiga(knjiga);
                    sacuvanaknjigaCollectionNewSacuvanaknjiga = em.merge(sacuvanaknjigaCollectionNewSacuvanaknjiga);
                    if (oldIdKnjigaOfSacuvanaknjigaCollectionNewSacuvanaknjiga != null && !oldIdKnjigaOfSacuvanaknjigaCollectionNewSacuvanaknjiga.equals(knjiga)) {
                        oldIdKnjigaOfSacuvanaknjigaCollectionNewSacuvanaknjiga.getSacuvanaknjigaCollection().remove(sacuvanaknjigaCollectionNewSacuvanaknjiga);
                        oldIdKnjigaOfSacuvanaknjigaCollectionNewSacuvanaknjiga = em.merge(oldIdKnjigaOfSacuvanaknjigaCollectionNewSacuvanaknjiga);
                    }
                }
            }
            for (Napisanaknjiga napisanaknjigaCollectionNewNapisanaknjiga : napisanaknjigaCollectionNew) {
                if (!napisanaknjigaCollectionOld.contains(napisanaknjigaCollectionNewNapisanaknjiga)) {
                    Knjiga oldIdKnjigaOfNapisanaknjigaCollectionNewNapisanaknjiga = napisanaknjigaCollectionNewNapisanaknjiga.getIdKnjiga();
                    napisanaknjigaCollectionNewNapisanaknjiga.setIdKnjiga(knjiga);
                    napisanaknjigaCollectionNewNapisanaknjiga = em.merge(napisanaknjigaCollectionNewNapisanaknjiga);
                    if (oldIdKnjigaOfNapisanaknjigaCollectionNewNapisanaknjiga != null && !oldIdKnjigaOfNapisanaknjigaCollectionNewNapisanaknjiga.equals(knjiga)) {
                        oldIdKnjigaOfNapisanaknjigaCollectionNewNapisanaknjiga.getNapisanaknjigaCollection().remove(napisanaknjigaCollectionNewNapisanaknjiga);
                        oldIdKnjigaOfNapisanaknjigaCollectionNewNapisanaknjiga = em.merge(oldIdKnjigaOfNapisanaknjigaCollectionNewNapisanaknjiga);
                    }
                }
            }
            for (Ocena ocenaCollectionNewOcena : ocenaCollectionNew) {
                if (!ocenaCollectionOld.contains(ocenaCollectionNewOcena)) {
                    Knjiga oldIdKnjigaOfOcenaCollectionNewOcena = ocenaCollectionNewOcena.getIdKnjiga();
                    ocenaCollectionNewOcena.setIdKnjiga(knjiga);
                    ocenaCollectionNewOcena = em.merge(ocenaCollectionNewOcena);
                    if (oldIdKnjigaOfOcenaCollectionNewOcena != null && !oldIdKnjigaOfOcenaCollectionNewOcena.equals(knjiga)) {
                        oldIdKnjigaOfOcenaCollectionNewOcena.getOcenaCollection().remove(ocenaCollectionNewOcena);
                        oldIdKnjigaOfOcenaCollectionNewOcena = em.merge(oldIdKnjigaOfOcenaCollectionNewOcena);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = knjiga.getIdKnjiga();
                if (findKnjiga(id) == null) {
                    throw new NonexistentEntityException("The knjiga with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Knjiga knjiga;
            try {
                knjiga = em.getReference(Knjiga.class, id);
                knjiga.getIdKnjiga();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The knjiga with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Sacuvanaknjiga> sacuvanaknjigaCollectionOrphanCheck = knjiga.getSacuvanaknjigaCollection();
            for (Sacuvanaknjiga sacuvanaknjigaCollectionOrphanCheckSacuvanaknjiga : sacuvanaknjigaCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Knjiga (" + knjiga + ") cannot be destroyed since the Sacuvanaknjiga " + sacuvanaknjigaCollectionOrphanCheckSacuvanaknjiga + " in its sacuvanaknjigaCollection field has a non-nullable idKnjiga field.");
            }
            Collection<Napisanaknjiga> napisanaknjigaCollectionOrphanCheck = knjiga.getNapisanaknjigaCollection();
            for (Napisanaknjiga napisanaknjigaCollectionOrphanCheckNapisanaknjiga : napisanaknjigaCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Knjiga (" + knjiga + ") cannot be destroyed since the Napisanaknjiga " + napisanaknjigaCollectionOrphanCheckNapisanaknjiga + " in its napisanaknjigaCollection field has a non-nullable idKnjiga field.");
            }
            Collection<Ocena> ocenaCollectionOrphanCheck = knjiga.getOcenaCollection();
            for (Ocena ocenaCollectionOrphanCheckOcena : ocenaCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Knjiga (" + knjiga + ") cannot be destroyed since the Ocena " + ocenaCollectionOrphanCheckOcena + " in its ocenaCollection field has a non-nullable idKnjiga field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Kategorija idKat = knjiga.getIdKat();
            if (idKat != null) {
                idKat.getKnjigaCollection().remove(knjiga);
                idKat = em.merge(idKat);
            }
            em.remove(knjiga);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Knjiga> findKnjigaEntities() {
        return findKnjigaEntities(true, -1, -1);
    }

    public List<Knjiga> findKnjigaEntities(int maxResults, int firstResult) {
        return findKnjigaEntities(false, maxResults, firstResult);
    }

    private List<Knjiga> findKnjigaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Knjiga.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Knjiga findKnjiga(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Knjiga.class, id);
        } finally {
            em.close();
        }
    }

    public int getKnjigaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Knjiga> rt = cq.from(Knjiga.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

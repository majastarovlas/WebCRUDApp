/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Knjiga;
import rs.ac.metropolitan.jpa.entity.Autor;
import rs.ac.metropolitan.jpa.entity.Napisanaknjiga;

/**
 *
 * @author MSI
 */
public class NapisanaknjigaJpaController implements Serializable {

    public NapisanaknjigaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Napisanaknjiga napisanaknjiga) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Knjiga idKnjiga = napisanaknjiga.getIdKnjiga();
            if (idKnjiga != null) {
                idKnjiga = em.getReference(idKnjiga.getClass(), idKnjiga.getIdKnjiga());
                napisanaknjiga.setIdKnjiga(idKnjiga);
            }
            Autor idAutor = napisanaknjiga.getIdAutor();
            if (idAutor != null) {
                idAutor = em.getReference(idAutor.getClass(), idAutor.getIdAutor());
                napisanaknjiga.setIdAutor(idAutor);
            }
            em.persist(napisanaknjiga);
            if (idKnjiga != null) {
                idKnjiga.getNapisanaknjigaCollection().add(napisanaknjiga);
                idKnjiga = em.merge(idKnjiga);
            }
            if (idAutor != null) {
                idAutor.getNapisanaknjigaCollection().add(napisanaknjiga);
                idAutor = em.merge(idAutor);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Napisanaknjiga napisanaknjiga) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Napisanaknjiga persistentNapisanaknjiga = em.find(Napisanaknjiga.class, napisanaknjiga.getIdNk());
            Knjiga idKnjigaOld = persistentNapisanaknjiga.getIdKnjiga();
            Knjiga idKnjigaNew = napisanaknjiga.getIdKnjiga();
            Autor idAutorOld = persistentNapisanaknjiga.getIdAutor();
            Autor idAutorNew = napisanaknjiga.getIdAutor();
            if (idKnjigaNew != null) {
                idKnjigaNew = em.getReference(idKnjigaNew.getClass(), idKnjigaNew.getIdKnjiga());
                napisanaknjiga.setIdKnjiga(idKnjigaNew);
            }
            if (idAutorNew != null) {
                idAutorNew = em.getReference(idAutorNew.getClass(), idAutorNew.getIdAutor());
                napisanaknjiga.setIdAutor(idAutorNew);
            }
            napisanaknjiga = em.merge(napisanaknjiga);
            if (idKnjigaOld != null && !idKnjigaOld.equals(idKnjigaNew)) {
                idKnjigaOld.getNapisanaknjigaCollection().remove(napisanaknjiga);
                idKnjigaOld = em.merge(idKnjigaOld);
            }
            if (idKnjigaNew != null && !idKnjigaNew.equals(idKnjigaOld)) {
                idKnjigaNew.getNapisanaknjigaCollection().add(napisanaknjiga);
                idKnjigaNew = em.merge(idKnjigaNew);
            }
            if (idAutorOld != null && !idAutorOld.equals(idAutorNew)) {
                idAutorOld.getNapisanaknjigaCollection().remove(napisanaknjiga);
                idAutorOld = em.merge(idAutorOld);
            }
            if (idAutorNew != null && !idAutorNew.equals(idAutorOld)) {
                idAutorNew.getNapisanaknjigaCollection().add(napisanaknjiga);
                idAutorNew = em.merge(idAutorNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = napisanaknjiga.getIdNk();
                if (findNapisanaknjiga(id) == null) {
                    throw new NonexistentEntityException("The napisanaknjiga with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Napisanaknjiga napisanaknjiga;
            try {
                napisanaknjiga = em.getReference(Napisanaknjiga.class, id);
                napisanaknjiga.getIdNk();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The napisanaknjiga with id " + id + " no longer exists.", enfe);
            }
            Knjiga idKnjiga = napisanaknjiga.getIdKnjiga();
            if (idKnjiga != null) {
                idKnjiga.getNapisanaknjigaCollection().remove(napisanaknjiga);
                idKnjiga = em.merge(idKnjiga);
            }
            Autor idAutor = napisanaknjiga.getIdAutor();
            if (idAutor != null) {
                idAutor.getNapisanaknjigaCollection().remove(napisanaknjiga);
                idAutor = em.merge(idAutor);
            }
            em.remove(napisanaknjiga);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Napisanaknjiga> findNapisanaknjigaEntities() {
        return findNapisanaknjigaEntities(true, -1, -1);
    }

    public List<Napisanaknjiga> findNapisanaknjigaEntities(int maxResults, int firstResult) {
        return findNapisanaknjigaEntities(false, maxResults, firstResult);
    }

    private List<Napisanaknjiga> findNapisanaknjigaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Napisanaknjiga.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Napisanaknjiga findNapisanaknjiga(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Napisanaknjiga.class, id);
        } finally {
            em.close();
        }
    }

    public int getNapisanaknjigaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Napisanaknjiga> rt = cq.from(Napisanaknjiga.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

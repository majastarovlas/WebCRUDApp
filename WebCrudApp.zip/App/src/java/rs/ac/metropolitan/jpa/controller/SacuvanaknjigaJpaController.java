/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.metropolitan.jpa.controller;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import rs.ac.metropolitan.jpa.controller.exceptions.NonexistentEntityException;
import rs.ac.metropolitan.jpa.controller.exceptions.RollbackFailureException;
import rs.ac.metropolitan.jpa.entity.Korisnik;
import rs.ac.metropolitan.jpa.entity.Knjiga;
import rs.ac.metropolitan.jpa.entity.Sacuvanaknjiga;

/**
 *
 * @author MSI
 */
public class SacuvanaknjigaJpaController implements Serializable {

    public SacuvanaknjigaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Sacuvanaknjiga sacuvanaknjiga) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik idKorisnik = sacuvanaknjiga.getIdKorisnik();
            if (idKorisnik != null) {
                idKorisnik = em.getReference(idKorisnik.getClass(), idKorisnik.getIdKorisnik());
                sacuvanaknjiga.setIdKorisnik(idKorisnik);
            }
            Knjiga idKnjiga = sacuvanaknjiga.getIdKnjiga();
            if (idKnjiga != null) {
                idKnjiga = em.getReference(idKnjiga.getClass(), idKnjiga.getIdKnjiga());
                sacuvanaknjiga.setIdKnjiga(idKnjiga);
            }
            em.persist(sacuvanaknjiga);
            if (idKorisnik != null) {
                idKorisnik.getSacuvanaknjigaCollection().add(sacuvanaknjiga);
                idKorisnik = em.merge(idKorisnik);
            }
            if (idKnjiga != null) {
                idKnjiga.getSacuvanaknjigaCollection().add(sacuvanaknjiga);
                idKnjiga = em.merge(idKnjiga);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Sacuvanaknjiga sacuvanaknjiga) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Sacuvanaknjiga persistentSacuvanaknjiga = em.find(Sacuvanaknjiga.class, sacuvanaknjiga.getIdSk());
            Korisnik idKorisnikOld = persistentSacuvanaknjiga.getIdKorisnik();
            Korisnik idKorisnikNew = sacuvanaknjiga.getIdKorisnik();
            Knjiga idKnjigaOld = persistentSacuvanaknjiga.getIdKnjiga();
            Knjiga idKnjigaNew = sacuvanaknjiga.getIdKnjiga();
            if (idKorisnikNew != null) {
                idKorisnikNew = em.getReference(idKorisnikNew.getClass(), idKorisnikNew.getIdKorisnik());
                sacuvanaknjiga.setIdKorisnik(idKorisnikNew);
            }
            if (idKnjigaNew != null) {
                idKnjigaNew = em.getReference(idKnjigaNew.getClass(), idKnjigaNew.getIdKnjiga());
                sacuvanaknjiga.setIdKnjiga(idKnjigaNew);
            }
            sacuvanaknjiga = em.merge(sacuvanaknjiga);
            if (idKorisnikOld != null && !idKorisnikOld.equals(idKorisnikNew)) {
                idKorisnikOld.getSacuvanaknjigaCollection().remove(sacuvanaknjiga);
                idKorisnikOld = em.merge(idKorisnikOld);
            }
            if (idKorisnikNew != null && !idKorisnikNew.equals(idKorisnikOld)) {
                idKorisnikNew.getSacuvanaknjigaCollection().add(sacuvanaknjiga);
                idKorisnikNew = em.merge(idKorisnikNew);
            }
            if (idKnjigaOld != null && !idKnjigaOld.equals(idKnjigaNew)) {
                idKnjigaOld.getSacuvanaknjigaCollection().remove(sacuvanaknjiga);
                idKnjigaOld = em.merge(idKnjigaOld);
            }
            if (idKnjigaNew != null && !idKnjigaNew.equals(idKnjigaOld)) {
                idKnjigaNew.getSacuvanaknjigaCollection().add(sacuvanaknjiga);
                idKnjigaNew = em.merge(idKnjigaNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = sacuvanaknjiga.getIdSk();
                if (findSacuvanaknjiga(id) == null) {
                    throw new NonexistentEntityException("The sacuvanaknjiga with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Sacuvanaknjiga sacuvanaknjiga;
            try {
                sacuvanaknjiga = em.getReference(Sacuvanaknjiga.class, id);
                sacuvanaknjiga.getIdSk();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The sacuvanaknjiga with id " + id + " no longer exists.", enfe);
            }
            Korisnik idKorisnik = sacuvanaknjiga.getIdKorisnik();
            if (idKorisnik != null) {
                idKorisnik.getSacuvanaknjigaCollection().remove(sacuvanaknjiga);
                idKorisnik = em.merge(idKorisnik);
            }
            Knjiga idKnjiga = sacuvanaknjiga.getIdKnjiga();
            if (idKnjiga != null) {
                idKnjiga.getSacuvanaknjigaCollection().remove(sacuvanaknjiga);
                idKnjiga = em.merge(idKnjiga);
            }
            em.remove(sacuvanaknjiga);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Sacuvanaknjiga> findSacuvanaknjigaEntities() {
        return findSacuvanaknjigaEntities(true, -1, -1);
    }

    public List<Sacuvanaknjiga> findSacuvanaknjigaEntities(int maxResults, int firstResult) {
        return findSacuvanaknjigaEntities(false, maxResults, firstResult);
    }

    private List<Sacuvanaknjiga> findSacuvanaknjigaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Sacuvanaknjiga.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Sacuvanaknjiga findSacuvanaknjiga(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Sacuvanaknjiga.class, id);
        } finally {
            em.close();
        }
    }

    public int getSacuvanaknjigaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Sacuvanaknjiga> rt = cq.from(Sacuvanaknjiga.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

package rs.ac.metropolitan.rest.client;

public class TestJavaClientKnjiga {

    public static void main(String[] args) {
        JavaClientKnjiga client = new JavaClientKnjiga();
        String jsonString = client.find_JSON(String.class, "1");
        
        System.out.println(jsonString);
        
        client.close();
    }
}
